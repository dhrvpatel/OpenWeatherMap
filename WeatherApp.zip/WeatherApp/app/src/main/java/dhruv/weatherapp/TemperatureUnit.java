package dhruv.weatherapp;

public enum TemperatureUnit {
    CELCIUS,
    FAHRENHEIT
}